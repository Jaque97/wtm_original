package com.ar.event

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
