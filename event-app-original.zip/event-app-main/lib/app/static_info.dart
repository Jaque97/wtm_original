import 'package:event_app/models/user_model.dart';

class StaticInfo {
  static UserModel userModel = UserModel(userType: "");
}
