import 'package:stacked/stacked.dart';

class ScanDetailViewModel extends BaseViewModel {}
